import { useEffect } from "react";
import { getRanking } from "./apis/ranking";

function App() {
  // 왜 사용되는지 이해가 안 되신다면, 아래 주석을 살리고 res 뒤에 .을 붙여서 내부 멤버들을 조회해보시기 바랍니다.
  // 참고로 당연하지만 아직 서버가 안 굴러가고 있어서 실행하면 오류가 납니다.
  // useEffect(()=>{
  //   getRanking().then((res)=>{
  //     console.log(res);
  //   })
  // })
  return <>BetGether</>;
}

export default App;
